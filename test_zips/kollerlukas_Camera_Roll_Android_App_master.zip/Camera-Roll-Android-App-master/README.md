[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Travis-ci](https://api.travis-ci.org/kollerlukas/Camera-Roll-Android-App.svg)](https://travis-ci.org/kollerlukas/Camera-Roll-Android-App)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/abf5a5e744c34396b20c1f7ed125ff04)](https://www.codacy.com/app/lukaskoller6/Camera-Roll-Android-App?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=kollerlukas/Camera-Roll-Android-App&amp;utm_campaign=Badge_Grade)

![PREVIEW](https://github.com/kollerlukas/Camera-Roll-Android-App/blob/master/camera_roll_banner.png)

# Camera Roll Android App
Simple Gallery App for Android, with lovely Material Design.<br>

<a href="https://play.google.com/store/apps/details?id=us.koller.cameraroll" target="_blank">
<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="80"/></a>

[<img src="https://f-droid.org/badge/get-it-on.png"
      alt="Get it on F-Droid"
      height="80">](https://f-droid.org/app/us.koller.cameraroll)

