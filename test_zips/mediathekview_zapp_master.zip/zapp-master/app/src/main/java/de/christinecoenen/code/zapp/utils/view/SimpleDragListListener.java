package de.christinecoenen.code.zapp.utils.view;

import com.woxthebox.draglistview.DragListView;


public class SimpleDragListListener implements DragListView.DragListListener {
	@Override
	public void onItemDragStarted(int position) {}

	@Override
	public void onItemDragging(int itemPosition, float x, float y) {}

	@Override
	public void onItemDragEnded(int fromPosition, int toPosition) {}
}
