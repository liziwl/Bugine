package de.christinecoenen.code.zapp.app.mediathek.api.result;


import java.util.List;

import de.christinecoenen.code.zapp.app.mediathek.model.MediathekShow;

@SuppressWarnings({"CanBeFinal", "unused"})
public class MediathekAnswerResult {

	public List<MediathekShow> results;

}
