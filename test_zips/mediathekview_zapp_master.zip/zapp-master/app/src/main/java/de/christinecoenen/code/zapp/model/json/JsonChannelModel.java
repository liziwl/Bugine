package de.christinecoenen.code.zapp.model.json;


import com.google.gson.annotations.SerializedName;

/**
 * Transitional model to store parsed json data.
 */
@SuppressWarnings({"CanBeFinal", "unused"})
class JsonChannelModel {
	@SerializedName("id")
	String id;

	@SerializedName("name")
	String name;

	@SerializedName("stream_url")
	String streamUrl;

	@SerializedName("logo_name")
	String logoName;

	@SerializedName("subtitle")
	String subtitle;

	@SerializedName("color")
	String color;
}
