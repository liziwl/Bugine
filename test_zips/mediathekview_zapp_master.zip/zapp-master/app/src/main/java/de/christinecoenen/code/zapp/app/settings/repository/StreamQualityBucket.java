package de.christinecoenen.code.zapp.app.settings.repository;

public enum StreamQualityBucket {
	DISABLED,
	LOWEST,
	MEDIUM,
	HIGHEST
}
