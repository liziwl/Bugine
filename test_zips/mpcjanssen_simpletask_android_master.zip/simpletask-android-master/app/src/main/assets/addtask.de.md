Aufgaben hinzufügen oder bearbeiten
--------

In diesem Fenster können Sie neue Aufgaben hinzufügen oder bestehende bearbeiten. Es gibt zwei Optionen:

* Zeilenumbruch: zeigt Aufgaben, die länger sind als die Fensterbreite in mehreren Zeilen an.
* Vorausfüllen: übernimmt bei einem Zeilenwechsel Tags und Listen aus der vorhergehenden Zeile. So können sehr einfach mehrere Aufgaben mit den selben Kategorien und Listen hinzugefügt werden.

Links
-----
- [Todo.txt Erweiterungen](./extensions.de.md)
- [Inhalt der Hilfe](./index.de.md)

