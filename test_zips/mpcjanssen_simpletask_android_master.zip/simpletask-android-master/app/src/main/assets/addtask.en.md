This screen allows you to add new tasks or updateCache existing ones. Every line in the text box will become one task. There are two checkboxes:

* Word wrap: Should long lines be wrapped or run off to the right.
* Pre-fill next: When checked, pressing next (or enter) on the keyboard will prefill the next line with the
 tags and lists of the previous line. This makes it very easy quickly add multiple tasks with the same lists and tags.

Links
-----
- [Todo.txt extensions](./extensions.en.md)
- [Help index](./index.en.md)

