Consideraciones de diseño
=========================

Consideraciones de diseño general
---------------------------------

-   Sencillo
    -   Interfaz de usuario sigue las directrices Android
-   Suficiente funcionalidad para hacer GTD
    -   Listas separadas
    -   Habilidad para etiquetar
-   Formato de almacenamiento documentado
    -   Formato todo.txt con manejo especial de (.....)
-   Aplicable para escenarios de uso múltiple
    -   Tendría que ser utilizable sin dropbox

Formato de archivo
------------------

### Listas (Contextos en todo.txt)

### Etiquetas (Proyectos en todo.txt)

### Notas (Ningún equivalente en todo.txt)

Otras consideraciones
---------------------

-   Simpletask está escrito de tal manera que la misma documentación se utiliza en Github y en la aplicación. Esto requiere algunas dependencias adicionales para la aplicación (un lector-analizador para Markdown y uno para HTML), pero permite que el mantener sincronizados todos los documentos sea mucho más fácil.

