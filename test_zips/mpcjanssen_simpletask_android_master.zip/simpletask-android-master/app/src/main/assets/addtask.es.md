Esta pantalla le permite añadir tareas nuevas o actualizar las que ya existen. Cada línea en la caja de texto se convertirá en una tarea. hay dos casillas opcionales:

* Salto de línea automático: Si las líneas largas deberían ser escritas en varias líneas o escapar por la derecha.
* Rellenar la próxima: Cuándo esta marcada, pulsando siguiente (o entrar) en el teclado  rellenará la línea próxima con las 
 etiquetas y listas de la línea anterior. Esto hace muy fácil añadir rápidamente múltiples tareas con las mismas listas y etiquetas.


Añadir Tarea
------------



Actualizar Tarea
----------------


Extensiones
-----------

Simpletask soporta las siguientes extensiones de todo.txt:

-   Fecha de vemcimiento: `due:YYYY-MM-DD` (año-mes-día)
-   Fecha umbral/de inicio: `t:YYYY-MM-DD`
-   Tareas recurrentes: `rec:[0-9]+[dwmy]` (días, semanas, meses, años) como se describe [aquí](https://github.com/bram85/todo.txt-tools/wiki/Recurrence) pero con alguna variación.
    - De forma predeterminada Simpletask utilizará las fechas originales de la tarea para crear la tarea recurrente, no la fecha de conclusión como se describe en el enlace. Este comportamiento puede ser configurado de los Ajustes.

Enlaces
------

- [Índice de ayuda](./index.es.md)

